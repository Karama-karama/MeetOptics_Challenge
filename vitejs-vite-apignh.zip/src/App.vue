<script setup>
// This starter template is using Vue 3 <script setup> SFCs
// Check out https://vuejs.org/api/sfc-script-setup.html#script-setup
import Antd from 'ant-design-vue';
import Home from './components/Home.vue';
import 'ant-design-vue/dist/antd.css';
</script>

<template>
  <!-- Image goes here i you want to  -->
  <Home />
</template>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
